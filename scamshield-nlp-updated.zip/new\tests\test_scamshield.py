"""
ScamShield Comprehensive Test Suite
Validates preprocessor, feature extractor, ML models, explainability, pipeline,
challenge evaluation engine, WhatsApp guardian, and email scanner.
"""

import os
import sys
import unittest
import pandas as pd

# Add project root to path
PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from src.preprocessor import (
    normalize_text,
    extract_urls,
    analyze_url,
    extract_phone_numbers,
    detect_pattern_triggers,
    compute_linguistic_features
)
from src.feature_extractor import ScamShieldFeatureExtractor
from src.models import ScamShieldModel
from src.explainability import ScamExplainer
from src.pipeline import ScamShieldPipeline
from src.whatsapp_guardian import WhatsAppGuardian, WhatsAppMessage
from src.email_scanner import EmailPhishingScanner
from src.clipboard_guard import ClipboardGuard
from src.telegram_guardian import TelegramGuardian, TelegramMessage
from src.qr_scanner import QuishingScanner
from src.localization import (
    SUPPORTED_LANGUAGES,
    detect_language,
    t,
    get_category_label,
    generate_auto_reply_warning,
    get_localized_presets,
    load_user_preferences,
    save_user_preferences
)
from challenge.evaluate_submission import evaluate

class TestScamShield(unittest.TestCase):

    def test_preprocessor_urls(self):
        text = "Check http://192.168.1.1/login and https://dbs-verify.xyz now"
        urls = extract_urls(text)
        self.assertEqual(len(urls), 2)

        ip_info = analyze_url("http://192.168.1.1/login")
        self.assertTrue(ip_info["is_ip"])
        self.assertGreaterEqual(ip_info["url_risk_score"], 40)

        tld_info = analyze_url("https://dbs-verify.xyz")
        self.assertTrue(tld_info["is_suspicious_tld"])
        self.assertEqual(tld_info["spoofed_brand"], "dbs")
        self.assertGreaterEqual(tld_info["url_risk_score"], 60)

    def test_pattern_detection(self):
        urgent_text = "URGENT: Your account has been suspended within 24 hours. Verify identity immediately."
        triggers = detect_pattern_triggers(urgent_text)
        self.assertGreater(len(triggers["urgency_triggers"]), 0)
        self.assertGreater(len(triggers["credential_triggers"]), 0)

        bait_text = "Congratulations! You won $250,000 in lucky draw. Guaranteed 300% ROI."
        triggers_bait = detect_pattern_triggers(bait_text)
        self.assertGreater(len(triggers_bait["bait_triggers"]), 0)

    def test_feature_extractor(self):
        texts = [
            "Your OTP is 123456. Valid for 2 mins.",
            "URGENT: Click http://scam.xyz to claim $500 bonus immediately!"
        ]
        fe = ScamShieldFeatureExtractor(max_features_word=100, max_features_char=100)
        fe.fit(texts)
        X = fe.transform(texts)
        self.assertEqual(X.shape[0], 2)
        self.assertGreater(X.shape[1], 10)

    def test_explainability(self):
        explainer = ScamExplainer()
        scam_text = "URGENT: OCBC alert! Verify identity at http://192.168.1.5/bank immediately or account suspended."
        exp = explainer.explain(
            text=scam_text,
            is_scam=True,
            scam_prob=0.95,
            category="bank_impersonation"
        )
        self.assertGreaterEqual(exp["risk_score"], 80)
        self.assertIn(exp["risk_level"], ["HIGH RISK", "CRITICAL DANGER"])
        self.assertGreater(len(exp["tactics_detected"]), 0)
        self.assertGreater(len(exp["safety_advice"]), 0)

    def test_pipeline_inference(self):
        pipeline = ScamShieldPipeline()
        self.assertTrue(pipeline.is_ready)

        # Test scam message
        scam_sample = "SingPost: Parcel held due to unpaid duty. Pay here: http://singpost-tracking-fees.top"
        res_scam = pipeline.scan_message(scam_sample)
        self.assertTrue(res_scam["is_scam"])
        self.assertEqual(res_scam["category"], "delivery_fraud")
        self.assertGreaterEqual(res_scam["risk_score"], 50)

        # Test legitimate message
        ham_sample = "Hey mom, I will be home around 7pm for dinner."
        res_ham = pipeline.scan_message(ham_sample)
        self.assertFalse(res_ham["is_scam"])
        self.assertEqual(res_ham["category"], "legitimate")
        self.assertLessEqual(res_ham["risk_score"], 35)

    def test_whatsapp_guardian(self):
        pipeline = ScamShieldPipeline()
        guardian = WhatsAppGuardian(pipeline)
        msg = WhatsAppMessage(
            sender_name="Telegram Job Recruiter",
            sender_number="+65 8123 9999",
            message_text="Earn $400 daily liking YouTube videos. Work from phone. WhatsApp me: +65 8123 9999",
            is_group=True,
            group_name="Daily Cash Income SG"
        )
        alert = guardian.inspect_message(msg)
        self.assertIn(alert["notification_type"], ["HIGH_RISK_WARNING", "CRITICAL_INTERCEPT"])
        self.assertGreaterEqual(alert["risk_score"], 50)
        self.assertEqual(alert["category"], "job_scam")
        self.assertTrue(len(alert["auto_reply_warning"]) > 0)

    def test_email_scanner(self):
        pipeline = ScamShieldPipeline()
        scanner = EmailPhishingScanner(pipeline)
        res = scanner.scan_email(
            sender_email="admin@dbs-corp-service.xyz",
            subject="URGENT: Outstanding Tax Fine Notice",
            body="IRAS tax audit requires immediate payment of $1,420: http://iras-tax-clearance.vip",
            reply_to="secret-account@gmail.com"
        )
        self.assertTrue(res["is_phishing"])
        self.assertTrue(res["domain_mismatch"])
        self.assertGreaterEqual(res["email_risk_score"], 60)

    def test_clipboard_guard(self):
        pipeline = ScamShieldPipeline()
        guard = ClipboardGuard(pipeline)
        alert = guard.inspect_clipboard_text("Verify OCBC account to avoid suspension: http://ocbc-auth-portal.online")
        self.assertIsNotNone(alert)
        self.assertGreaterEqual(alert["risk_score"], 50)

    def test_telegram_guardian(self):
        pipeline = ScamShieldPipeline()
        guardian = TelegramGuardian(pipeline)
        msg = TelegramMessage(
            sender_username="CryptoVIP_Bot",
            chat_title="Singapore Wealth Signals",
            message_text="Exclusive VIP Crypto Signals! Guaranteed 300% to 500% returns in 7 days using automated AI quant bot. Join Telegram bot @crypto_bot or http://crypto-vault.xyz",
            is_bot=True
        )
        alert = guardian.inspect_message(msg)
        self.assertGreaterEqual(alert["risk_score"], 70)
        self.assertEqual(alert["category"], "investment_crypto")
        self.assertEqual(alert["action_taken"], "KICK_AND_DELETE_MESSAGE")
        self.assertTrue(len(alert["auto_reply_warning"]) > 0)

    def test_quishing_scanner(self):
        pipeline = ScamShieldPipeline()
        scanner = QuishingScanner(pipeline)
        report = scanner.scan_qr_payload(
            payload_text="Scan QR code to settle unpaid HDB parking penalty: http://hdb-parking-notice.top/paynow",
            source_context="Tampered parking meter sticker"
        )
        self.assertGreaterEqual(report["risk_score"], 75)
        self.assertIn("parking-notice.top", report["detected_urls"][0])
        self.assertEqual(report["action_recommendation"], "DO_NOT_SCAN_OR_PAY")

    def test_challenge_evaluation(self):
        sub_path = os.path.join(PROJECT_ROOT, "challenge", "sample_submission.csv")
        gt_path = os.path.join(PROJECT_ROOT, "data", "test_ground_truth.csv")
        metrics = evaluate(sub_path, gt_path)

        self.assertIn("composite_score", metrics)
        self.assertIn("binary_macro_f1", metrics)
        self.assertIn("multiclass_macro_f1", metrics)
        self.assertGreater(metrics["composite_score"], 90.0)

    def test_language_preferences_and_localization(self):
        # 1. Supported languages check
        self.assertIn("en", SUPPORTED_LANGUAGES)
        self.assertIn("zh", SUPPORTED_LANGUAGES)
        self.assertIn("ms", SUPPORTED_LANGUAGES)
        self.assertIn("ta", SUPPORTED_LANGUAGES)
        self.assertIn("hi", SUPPORTED_LANGUAGES)

        # 2. Language Detection
        self.assertEqual(detect_language("华侨银行紧急通知：您的数字安全令牌已失效"), "zh")
        self.assertEqual(detect_language("உடனடியாக உங்கள் கணக்கை சரிபார்க்கவும்"), "ta")
        self.assertEqual(detect_language("तुरंत अपना बैंक खाता वेरीफाई करें"), "hi")
        self.assertEqual(detect_language("Sila bayar cukai kastam bagi pelepasan bungkusan akaun anda segera"), "ms")
        self.assertEqual(detect_language("Your OCBC token has expired today. Re-activate now."), "en")

        # 3. Multilingual pattern triggers in preprocessor
        zh_patterns = detect_pattern_triggers("紧急通知！日赚$500，请提供验证码进行激活")
        self.assertGreaterEqual(len(zh_patterns["urgency_triggers"]), 1)
        self.assertGreaterEqual(len(zh_patterns["bait_triggers"]), 1)
        self.assertGreaterEqual(len(zh_patterns["credential_triggers"]), 1)

        # 4. Translations and Typology labels
        self.assertIn("银行", get_category_label("bank_impersonation", "zh"))
        self.assertIn("Bank", get_category_label("bank_impersonation", "ms"))
        self.assertIn("வங்கி", get_category_label("bank_impersonation", "ta"))
        self.assertIn("बैंक", get_category_label("bank_impersonation", "hi"))

        # 5. Localized Auto-Reply Warning
        zh_reply = generate_auto_reply_warning("bank_impersonation", 85.0, lang="zh")
        self.assertIn("ScamShield", zh_reply)
        self.assertIn("银行", zh_reply)

        # 6. Presets per language
        zh_presets = get_localized_presets("zh")
        self.assertGreater(len(zh_presets), 5)

        # 7. Preferences persistence
        save_success = save_user_preferences({"preferred_language": "zh", "auto_detect_language": True})
        self.assertTrue(save_success)
        loaded = load_user_preferences()
        self.assertEqual(loaded["preferred_language"], "zh")
        # Reset back to en
        save_user_preferences({"preferred_language": "en"})

    def test_pipeline_multilingual_scan(self):
        pipeline = ScamShieldPipeline()
        # Scan in Chinese
        res_zh = pipeline.scan_message("华侨银行紧急通知：数字令牌已失效，立即点击验证：http://ocbc-auth-portal.online", lang="zh")
        self.assertTrue(res_zh["is_scam"])
        self.assertGreaterEqual(res_zh["risk_score"], 50)
        self.assertIn("银行", res_zh["category_label"])
        self.assertGreaterEqual(len(res_zh["safety_advice"]), 1)

        # WhatsApp guardian in Chinese
        wa = WhatsAppGuardian(pipeline)
        wa_msg = WhatsAppMessage(
            sender_name="人事招聘",
            sender_number="+65 8921 4452",
            message_text="日赚$500居家兼职，点击链接注册：http://job-daily-income.xyz"
        )
        wa_alert = wa.inspect_message(wa_msg, lang="zh")
        self.assertGreaterEqual(wa_alert["risk_score"], 50)
        self.assertIn("ScamShield", wa_alert["auto_reply_warning"])

if __name__ == "__main__":
    unittest.main()
