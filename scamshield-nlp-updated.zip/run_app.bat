@echo off
title ScamShield NLP Web App
echo ===================================================
echo   Starting ScamShield NLP Web Application...
echo ===================================================
cd /d "%~dp0"
python -m streamlit run src/app.py
pause
